#define ID_SERIAL 0
#define ID_CONSOLE 1

char* hexdigtoa(uint8_t i);